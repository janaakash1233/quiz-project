const quizData = {
  title: "Computer Science and Engineering Quiz"
};

const questions = [
  {
    text: "What does the acronym SQL stand for?",
    type: "mc",
    answers: [
      { text: "Structured Text Query Language", correct: false },
      { text: "Systematic Transfer and Query Language", correct: false },
      { text: "Structured Query Language", correct: true },
      { text: "Sequential Text Query Language", correct: false }
    ]
  },
  {
    text: "In computer networks, what does the term 'IP' stand for?",
    type: "mc",
    answers: [
      { text: "Internet Protocol", correct: true },
      { text: "Internal Processing", correct: false },
      { text: "Interconnected Port", correct: false },
      { text: "Innovative Programming", correct: false }
    ]
  },
  {
    text: "Which data structure is used for quick search and insertion of elements?",
    type: "mc",
    answers: [
      { text: "Array", correct: false },
      { text: "Linked List", correct: false },
      { text: "Hash Table", correct: true },
      { text: "Stack", correct: false }
    ]
  },
  {
    text: "What is the purpose of an 'else' statement in programming?",
    type: "mc",
    answers: [
      { text: "To initiate a loop", correct: false },
      { text: "To define a function", correct: false },
      { text: "To execute code when the 'if' condition is false", correct: true },
      { text: "To assign values to variables", correct: false }
    ]
  },
  {
    text: "Which programming language is known for its use in web development and is often used on the client side?",
    type: "mc",
    answers: [
      { text: "Java", correct: false },
      { text: "Python", correct: false },
      { text: "JavaScript", correct: true },
      { text: "C#", correct: false }
    ]
  },
  {
    text: "What is the purpose of an 'index' in a database?",
    type: "mc",
    answers: [
      { text: "To sort data alphabetically", correct: false },
      { text: "To speed up data retrieval operations", correct: true },
      { text: "To create backup copies of data", correct: false },
      { text: "To encrypt sensitive information", correct: false }
    ]
  },
  {
    text: "Which sorting algorithm has a time complexity of O(n^2) in the worst case?",
    type: "mc",
    answers: [
      { text: "Quick Sort", correct: false },
      { text: "Bubble Sort", correct: true },
      { text: "Merge Sort", correct: false },
      { text: "Insertion Sort", correct: false }
    ]
  },
  {
    text: "In networking, what does the acronym 'LAN' stand for?",
    type: "mc",
    answers: [
      { text: "Local Area Network", correct: true },
      { text: "Large Area Network", correct: false },
      { text: "Logical Access Node", correct: false },
      { text: "Linear Algebraic Network", correct: false }
    ]
  },
  {
    text: "What is the primary function of the 'git' version control system?",
    type: "mc",
    answers: [
      { text: "To compile code", correct: false },
      { text: "To manage project dependencies", correct: false },
      { text: "To track changes in source code and coordinate work among multiple developers", correct: true },
      { text: "To generate documentation", correct: false }
    ]
  },
  {
    text: "Which programming paradigm emphasizes the use of functions and avoids changing state and mutable data?",
    type: "mc",
    answers: [
      { text: "Procedural programming", correct: false },
      { text: "Object-oriented programming", correct: false },
      { text: "Functional programming", correct: true },
      { text: "Event-driven programming", correct: false }
    ]
  },
  {
    text: "What does the acronym 'HTTP' stand for?",
    type: "mc",
    answers: [
      { text: "Hyper Text Transfer Protocol", correct: true },
      { text: "High-Level Text Processing", correct: false },
      { text: "Hyperlink and Text Transmission Protocol", correct: false },
      { text: "Hyper Transfer Text Protocol", correct: false }
    ]
  },
  {
    text: "In the context of databases, what is the purpose of a 'primary key'?",
    type: "mc",
    answers: [
      { text: "To provide a secure login for users", correct: false },
      { text: "To uniquely identify each record in a table", correct: true },
      { text: "To encrypt sensitive data", correct: false },
      { text: "To create relationships between tables", correct: false }
    ]
  },
  {
    text: "Which of the following is a fundamental building block of blockchain technology?",
    type: "mc",
    answers: [
      { text: "Smart Contracts", correct: true },
      { text: "Cookies", correct: false },
      { text: "Cache Memory", correct: false },
      { text: "Virtual Machines", correct: false }
    ]
  },
  {
    text: "What is the purpose of the 'try...catch' block in programming?",
    type: "mc",
    answers: [
      { text: "To define a loop", correct: false },
      { text: "To handle exceptions and prevent program crashes", correct: true },
      { text: "To declare variables", correct: false },
      { text: "To create classes", correct: false }
    ]
  },
  {
    text: "Which encryption algorithm is commonly used for secure communication over a computer network?",
    type: "mc",
    answers: [
      { text: "SSL/TLS", correct: true },
      { text: "AES", correct: false },
      { text: "DES", correct: false },
      { text: "RSA", correct: false }
    ]
  },
  {
    text: "What is the primary function of a router in a computer network?",
    type: "mc",
    answers: [
      { text: "Connects devices within a local network", correct: false },
      { text: "Filters and forwards data between different networks", correct: true },
      { text: "Manages power supply to devices", correct: false },
      { text: "Stores and retrieves data", correct: false }
    ]
  },
  {
    text: "What is the purpose of an 'API' (Application Programming Interface)?",
    type: "mc",
    answers: [
      { text: "To create graphical elements", correct: false },
      { text: "To design user interfaces", correct: false },
      { text: "To allow different software components to communicate with each other",
    }
    ]
  }

];

module.exports = { quizData, questions };
